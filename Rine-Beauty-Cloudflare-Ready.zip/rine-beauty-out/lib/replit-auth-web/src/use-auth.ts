import { useCallback, useEffect, useState } from 'react';
import { getBaseUrl, type AuthUser } from '@workspace/api-client-react';

export type { AuthUser };

interface AuthState {
  user: AuthUser | null;
  isLoading: boolean;
  isAuthenticated: boolean;
  login: () => void;
  logout: () => void;
}

// Cross-domain API base URL (if any) is set once in main.tsx via
// setBaseUrl() from @workspace/api-client-react — see .env.example.
function apiUrl(path: string): string {
  return `${getBaseUrl() ?? ''}${path}`;
}

function getBasePath() {
  return import.meta.env.BASE_URL.replace(/\/+$/, '') || '/';
}

export function useAuth(): AuthState {
  const [user, setUser] = useState<AuthUser | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;

    fetch(apiUrl('/api/auth/user'), { credentials: 'include' })
      .then((res) => {
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        return res.json() as Promise<{ user: AuthUser | null }>;
      })
      .then((data) => {
        if (!cancelled) {
          setUser(data.user ?? null);
          setIsLoading(false);
        }
      })
      .catch(() => {
        if (!cancelled) {
          setUser(null);
          setIsLoading(false);
        }
      });

    return () => {
      cancelled = true;
    };
  }, []);

  const login = useCallback(() => {
    const base = getBasePath();
    window.location.href = apiUrl(`/api/login?returnTo=${encodeURIComponent(base)}`);
  }, []);

  const logout = useCallback(() => {
    fetch(apiUrl('/api/logout'), {
      method: 'POST',
      credentials: 'include',
    }).finally(() => {
      window.location.href = getBasePath();
    });
  }, []);

  return {
    user,
    isLoading,
    isAuthenticated: !!user,
    login,
    logout,
  };
}
