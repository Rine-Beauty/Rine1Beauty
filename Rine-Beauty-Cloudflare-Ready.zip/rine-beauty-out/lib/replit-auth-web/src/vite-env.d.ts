// Minimal ambient declaration so this composite lib can reference
// `import.meta.env.BASE_URL` without depending on the `vite` package
// (the consuming app provides the real values at build/runtime).
interface ImportMetaEnv {
  readonly BASE_URL: string;
}

interface ImportMeta {
  readonly env: ImportMetaEnv;
}
