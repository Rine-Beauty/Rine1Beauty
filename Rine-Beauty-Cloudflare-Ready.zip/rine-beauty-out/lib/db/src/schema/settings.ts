import { pgTable, serial, text } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

// Singleton table -- always exactly one row (id = 1).
export const storeSettingsTable = pgTable("store_settings", {
  id: serial("id").primaryKey(),
  storeName: text("store_name").notNull().default("Rine Beauty"),
  tagline: text("tagline").notNull().default(""),
  backgroundColor: text("background_color"),
  instagramUrl: text("instagram_url"),
  whatsappNumber: text("whatsapp_number"),
  logoObjectPath: text("logo_object_path"),
  bannerObjectPath: text("banner_object_path"),
});

export const insertStoreSettingsSchema = createInsertSchema(
  storeSettingsTable,
).omit({ id: true });
export type InsertStoreSettings = z.infer<typeof insertStoreSettingsSchema>;
export type StoreSettingsRow = typeof storeSettingsTable.$inferSelect;
