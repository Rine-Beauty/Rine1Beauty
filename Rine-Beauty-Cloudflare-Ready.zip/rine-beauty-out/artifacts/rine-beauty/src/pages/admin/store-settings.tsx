import { useState, useRef, useEffect } from 'react';
import { useGetSettings, useUpdateSettings, getGetSettingsQueryKey } from '@workspace/api-client-react';
import { useUpload } from '@workspace/object-storage-web';
import { useQueryClient } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { toast } from 'sonner';
import { Upload, X, Loader2 } from 'lucide-react';

export function StoreSettings() {
  const { data: settings, isLoading } = useGetSettings();
  const updateSettings = useUpdateSettings();
  const queryClient = useQueryClient();
  
  const [formData, setFormData] = useState({
    storeName: '',
    tagline: '',
    backgroundColor: '',
    instagramUrl: '',
    whatsappNumber: '',
  });

  const initializedRef = useRef(false);

  useEffect(() => {
    if (settings && !initializedRef.current) {
      setFormData({
        storeName: settings.storeName || '',
        tagline: settings.tagline || '',
        backgroundColor: settings.backgroundColor || '',
        instagramUrl: settings.instagramUrl || '',
        whatsappNumber: settings.whatsappNumber || '',
      });
      initializedRef.current = true;
    }
  }, [settings]);

  const { uploadFile: uploadLogo, isUploading: isLogoUploading } = useUpload({
    onSuccess: (res) => {
      handleSave({ logoObjectPath: res.objectPath });
    },
    onError: () => toast.error('فشل رفع الشعار')
  });

  const { uploadFile: uploadBanner, isUploading: isBannerUploading } = useUpload({
    onSuccess: (res) => {
      handleSave({ bannerObjectPath: res.objectPath });
    },
    onError: () => toast.error('فشل رفع البانر')
  });

  const handleSave = (partialData?: any) => {
    const dataToSave = partialData || formData;
    updateSettings.mutate({ data: dataToSave }, {
      onSuccess: (updatedData) => {
        toast.success('تم حفظ الإعدادات بنجاح');
        queryClient.setQueryData(getGetSettingsQueryKey(), updatedData);
      },
      onError: (err: any) => {
        if (err?.status === 403) {
          toast.error('غير مصرح لك بتعديل الإعدادات');
        } else {
          toast.error('حدث خطأ أثناء حفظ الإعدادات');
        }
      }
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    handleSave();
  };

  if (isLoading) return <div className="p-8 text-center text-muted-foreground">جاري التحميل...</div>;

  return (
    <div className="grid lg:grid-cols-3 gap-8">
      <div className="lg:col-span-2 space-y-6">
        <form onSubmit={handleSubmit}>
          <Card>
            <CardHeader>
              <CardTitle className="font-serif">المعلومات الأساسية</CardTitle>
              <CardDescription>المعلومات التي تظهر لعملائك في المتجر</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="storeName">اسم المتجر</Label>
                <Input 
                  id="storeName" 
                  value={formData.storeName} 
                  onChange={(e) => setFormData({ ...formData, storeName: e.target.value })} 
                  required 
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="tagline">الشعار اللفظي (Tagline)</Label>
                <Textarea 
                  id="tagline" 
                  value={formData.tagline} 
                  onChange={(e) => setFormData({ ...formData, tagline: e.target.value })} 
                  rows={2}
                />
              </div>
              <div className="grid sm:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="whatsappNumber">رقم الواتساب (للطلبات)</Label>
                  <Input 
                    id="whatsappNumber" 
                    value={formData.whatsappNumber} 
                    onChange={(e) => setFormData({ ...formData, whatsappNumber: e.target.value })} 
                    placeholder="مثال: 966500000000"
                    dir="ltr"
                    className="text-right"
                  />
                  <p className="text-xs text-muted-foreground">أدخل الرقم بالصيغة الدولية بدون أصفار أو + في البداية.</p>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="instagramUrl">رابط انستقرام</Label>
                  <Input 
                    id="instagramUrl" 
                    type="url"
                    value={formData.instagramUrl} 
                    onChange={(e) => setFormData({ ...formData, instagramUrl: e.target.value })} 
                    dir="ltr"
                    className="text-right"
                  />
                </div>
              </div>
              
              <div className="pt-4">
                <Button type="submit" disabled={updateSettings.isPending}>
                  {updateSettings.isPending ? <Loader2 className="h-4 w-4 animate-spin me-2" /> : null}
                  حفظ التغييرات
                </Button>
              </div>
            </CardContent>
          </Card>
        </form>
      </div>

      <div className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle className="font-serif">شعار المتجر</CardTitle>
          </CardHeader>
          <CardContent className="flex flex-col gap-4">
            {settings?.logoObjectPath ? (
              <div className="relative aspect-square w-full max-w-[200px] mx-auto border rounded-md overflow-hidden bg-muted flex items-center justify-center p-4">
                <img src={`/api/storage${settings.logoObjectPath}`} alt="Logo" className="max-w-full max-h-full object-contain" />
                <Button 
                  variant="destructive" 
                  size="icon" 
                  className="absolute top-2 right-2 h-8 w-8"
                  onClick={() => handleSave({ logoObjectPath: null })}
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>
            ) : (
              <div className="aspect-square w-full max-w-[200px] mx-auto border border-dashed rounded-md bg-muted/50 flex flex-col items-center justify-center text-muted-foreground p-6 text-center">
                <p className="text-sm mb-2">لا يوجد شعار</p>
              </div>
            )}
            
            <div className="relative">
              <Input 
                type="file" 
                accept="image/*"
                className="absolute inset-0 w-full h-full opacity-0 cursor-pointer" 
                onChange={(e) => e.target.files?.[0] && uploadLogo(e.target.files[0])}
                disabled={isLogoUploading}
              />
              <Button variant="outline" className="w-full pointer-events-none" disabled={isLogoUploading}>
                {isLogoUploading ? <Loader2 className="h-4 w-4 animate-spin me-2" /> : <Upload className="h-4 w-4 me-2" />}
                {isLogoUploading ? 'جاري الرفع...' : 'رفع شعار جديد'}
              </Button>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="font-serif">بانر الرئيسية</CardTitle>
          </CardHeader>
          <CardContent className="flex flex-col gap-4">
            {settings?.bannerObjectPath ? (
              <div className="relative aspect-video w-full border rounded-md overflow-hidden bg-muted flex items-center justify-center">
                <img src={`/api/storage${settings.bannerObjectPath}`} alt="Banner" className="w-full h-full object-cover" />
                <Button 
                  variant="destructive" 
                  size="icon" 
                  className="absolute top-2 right-2 h-8 w-8 shadow-sm"
                  onClick={() => handleSave({ bannerObjectPath: null })}
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>
            ) : (
              <div className="aspect-video w-full border border-dashed rounded-md bg-muted/50 flex flex-col items-center justify-center text-muted-foreground">
                <p className="text-sm">لا يوجد بانر</p>
              </div>
            )}
            
            <div className="relative">
              <Input 
                type="file" 
                accept="image/*"
                className="absolute inset-0 w-full h-full opacity-0 cursor-pointer" 
                onChange={(e) => e.target.files?.[0] && uploadBanner(e.target.files[0])}
                disabled={isBannerUploading}
              />
              <Button variant="outline" className="w-full pointer-events-none" disabled={isBannerUploading}>
                {isBannerUploading ? <Loader2 className="h-4 w-4 animate-spin me-2" /> : <Upload className="h-4 w-4 me-2" />}
                {isBannerUploading ? 'جاري الرفع...' : 'رفع بانر جديد'}
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}