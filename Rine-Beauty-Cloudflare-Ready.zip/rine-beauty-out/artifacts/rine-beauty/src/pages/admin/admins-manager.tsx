import { useEffect, useState } from 'react';
import { getBaseUrl } from '@workspace/api-client-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Trash2, ShieldCheck, UserPlus } from 'lucide-react';

interface AdminRow {
  email: string;
  isPrimary: boolean;
}

function apiUrl(path: string) {
  return `${getBaseUrl() ?? ''}${path}`;
}

export function AdminsManager() {
  const [admins, setAdmins] = useState<AdminRow[] | null>(null);
  const [newEmail, setNewEmail] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function refresh() {
    const res = await fetch(apiUrl('/api/admins'), { credentials: 'include' });
    if (res.ok) {
      const data = await res.json();
      setAdmins(data.admins);
    }
  }

  useEffect(() => {
    refresh();
  }, []);

  async function handleAdd(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setBusy(true);
    const res = await fetch(apiUrl('/api/admins'), {
      method: 'POST',
      credentials: 'include',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email: newEmail }),
    });
    setBusy(false);
    if (!res.ok) {
      const data = await res.json().catch(() => null);
      setError(data?.error ?? 'تعذّرت الإضافة');
      return;
    }
    const data = await res.json();
    setAdmins(data.admins);
    setNewEmail('');
  }

  async function handleRemove(email: string) {
    setBusy(true);
    const res = await fetch(apiUrl(`/api/admins/${encodeURIComponent(email)}`), {
      method: 'DELETE',
      credentials: 'include',
    });
    setBusy(false);
    if (res.ok) {
      const data = await res.json();
      setAdmins(data.admins);
    }
  }

  return (
    <div className="max-w-xl flex flex-col gap-6">
      <div>
        <h2 className="text-xl font-bold mb-1">المشرفون</h2>
        <p className="text-sm text-muted-foreground">
          فقط المشرف الأساسي يقدر يضيف أو يحذف مشرفين. تسجيل الدخول لكل المشرفين
          يكون عبر حساب Google.
        </p>
      </div>

      <form onSubmit={handleAdd} className="flex gap-2 items-start">
        <Input
          type="email"
          placeholder="admin@gmail.com"
          value={newEmail}
          onChange={(e) => setNewEmail(e.target.value)}
          required
          className="flex-1"
        />
        <Button type="submit" disabled={busy}>
          <UserPlus className="h-4 w-4 ms-2" />
          إضافة
        </Button>
      </form>
      {error && <p className="text-sm text-destructive">{error}</p>}

      <div className="border rounded-lg divide-y">
        {admins === null && (
          <p className="p-4 text-sm text-muted-foreground">جاري التحميل...</p>
        )}
        {admins?.map((admin) => (
          <div key={admin.email} className="flex items-center justify-between p-3">
            <div className="flex items-center gap-2">
              {admin.isPrimary && (
                <ShieldCheck className="h-4 w-4 text-primary" aria-label="المشرف الأساسي" />
              )}
              <span className="text-sm">{admin.email}</span>
              {admin.isPrimary && (
                <span className="text-xs text-muted-foreground">(أساسي)</span>
              )}
            </div>
            {!admin.isPrimary && (
              <Button
                variant="ghost"
                size="sm"
                disabled={busy}
                onClick={() => handleRemove(admin.email)}
                className="text-muted-foreground hover:text-destructive"
              >
                <Trash2 className="h-4 w-4" />
              </Button>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
