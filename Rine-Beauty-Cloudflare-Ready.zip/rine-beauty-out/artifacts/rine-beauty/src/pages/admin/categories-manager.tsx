import { useState } from 'react';
import { useListCategories, useCreateCategory, useDeleteCategory, getListCategoriesQueryKey } from '@workspace/api-client-react';
import { useQueryClient } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { toast } from 'sonner';
import { Trash2, Plus, Loader2 } from 'lucide-react';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

export function CategoriesManager() {
  const { data: categories, isLoading } = useListCategories();
  const createCategory = useCreateCategory();
  const deleteCategory = useDeleteCategory();
  const queryClient = useQueryClient();
  
  const [newCategoryName, setNewCategoryName] = useState('');

  const handleAddCategory = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCategoryName.trim()) return;

    createCategory.mutate({ data: { name: newCategoryName.trim() } }, {
      onSuccess: () => {
        toast.success('تمت إضافة القسم بنجاح');
        setNewCategoryName('');
        queryClient.invalidateQueries({ queryKey: getListCategoriesQueryKey() });
      },
      onError: (err: any) => {
        if (err?.status === 403) {
          toast.error('غير مصرح لك بإضافة قسم');
        } else {
          toast.error('حدث خطأ أثناء إضافة القسم');
        }
      }
    });
  };

  const handleDeleteCategory = (id: number) => {
    deleteCategory.mutate({ id }, {
      onSuccess: () => {
        toast.success('تم حذف القسم بنجاح');
        queryClient.invalidateQueries({ queryKey: getListCategoriesQueryKey() });
      },
      onError: (err: any) => {
        if (err?.status === 403) {
          toast.error('غير مصرح لك بحذف قسم');
        } else {
          toast.error('حدث خطأ أثناء حذف القسم. قد يكون مرتبطاً بمنتجات.');
        }
      }
    });
  };

  return (
    <div className="grid md:grid-cols-3 gap-8">
      <div className="md:col-span-1">
        <Card>
          <CardHeader>
            <CardTitle className="font-serif">إضافة قسم جديد</CardTitle>
            <CardDescription>أضف أقساماً لتنظيم منتجاتك وتسهيل التصفح للعملاء</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleAddCategory} className="flex flex-col gap-4">
              <Input 
                placeholder="اسم القسم (مثال: العناية بالبشرة)" 
                value={newCategoryName}
                onChange={(e) => setNewCategoryName(e.target.value)}
                required
              />
              <Button type="submit" disabled={!newCategoryName.trim() || createCategory.isPending}>
                {createCategory.isPending ? <Loader2 className="h-4 w-4 animate-spin me-2" /> : <Plus className="h-4 w-4 me-2" />}
                إضافة قسم
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>

      <div className="md:col-span-2">
        <Card>
          <CardHeader>
            <CardTitle className="font-serif">الأقسام الحالية</CardTitle>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="flex justify-center p-8">
                <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
              </div>
            ) : categories && categories.length > 0 ? (
              <div className="flex flex-col border rounded-md divide-y">
                {categories.map((category) => (
                  <div key={category.id} className="flex items-center justify-between p-4 bg-card hover:bg-muted/50 transition-colors">
                    <span className="font-medium text-foreground">{category.name}</span>
                    <AlertDialog>
                      <AlertDialogTrigger asChild>
                        <Button variant="ghost" size="icon" className="text-destructive hover:bg-destructive/10">
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </AlertDialogTrigger>
                      <AlertDialogContent>
                        <AlertDialogHeader>
                          <AlertDialogTitle>هل أنت متأكد من حذف القسم؟</AlertDialogTitle>
                          <AlertDialogDescription>
                            لا يمكن التراجع عن هذا الإجراء. سيؤدي هذا إلى حذف القسم "{category.name}". المنتجات المرتبطة بهذا القسم ستصبح بدون قسم.
                          </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                          <AlertDialogCancel>إلغاء</AlertDialogCancel>
                          <AlertDialogAction 
                            className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                            onClick={() => handleDeleteCategory(category.id)}
                          >
                            حذف
                          </AlertDialogAction>
                        </AlertDialogFooter>
                      </AlertDialogContent>
                    </AlertDialog>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center p-8 text-muted-foreground border border-dashed rounded-md bg-muted/20">
                لا توجد أقسام مضافة بعد.
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}