import { useState } from 'react';
import { useListProducts, useCreateProduct, useUpdateProduct, useDeleteProduct, useListCategories, getListProductsQueryKey } from '@workspace/api-client-react';
import { useUpload } from '@workspace/object-storage-web';
import { useQueryClient } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Card, CardContent } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from 'sonner';
import { Trash2, Plus, Pencil, Loader2, Search, Image as ImageIcon, X } from 'lucide-react';
import { formatCurrency } from '@/lib/utils';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

export function ProductsManager() {
  const [search, setSearch] = useState('');
  const { data: products, isLoading } = useListProducts({ search: search || undefined });
  const { data: categories } = useListCategories();
  const deleteProduct = useDeleteProduct();
  const queryClient = useQueryClient();
  
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<any>(null);

  const handleDelete = (id: number) => {
    deleteProduct.mutate({ id }, {
      onSuccess: () => {
        toast.success('تم حذف المنتج بنجاح');
        queryClient.invalidateQueries({ queryKey: getListProductsQueryKey() });
      },
      onError: (err: any) => {
        if (err?.status === 403) {
          toast.error('غير مصرح لك بحذف المنتج');
        } else {
          toast.error('حدث خطأ أثناء الحذف');
        }
      }
    });
  };

  const openNewForm = () => {
    setEditingProduct(null);
    setIsFormOpen(true);
  };

  const openEditForm = (product: any) => {
    setEditingProduct(product);
    setIsFormOpen(true);
  };

  return (
    <div className="flex flex-col gap-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div className="relative w-full sm:w-80">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input 
            placeholder="البحث عن منتج..." 
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-3 pr-10"
          />
        </div>
        <Button onClick={openNewForm} className="w-full sm:w-auto">
          <Plus className="h-4 w-4 me-2" />
          إضافة منتج جديد
        </Button>
      </div>

      <Card>
        <CardContent className="p-0">
          {isLoading ? (
            <div className="flex justify-center p-12">
              <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
            </div>
          ) : products && products.length > 0 ? (
            <div className="divide-y">
              {products.map((product) => (
                <div key={product.id} className="flex flex-col sm:flex-row sm:items-center gap-4 p-4 hover:bg-muted/30 transition-colors">
                  <div className="flex items-center gap-4 flex-1">
                    <div className="h-16 w-16 bg-muted rounded border shrink-0 overflow-hidden">
                      {product.imageObjectPath ? (
                        <img src={`/api/storage${product.imageObjectPath}`} alt={product.name} className="h-full w-full object-cover" />
                      ) : (
                        <div className="h-full w-full flex items-center justify-center text-muted-foreground"><ImageIcon className="h-6 w-6 opacity-50" /></div>
                      )}
                    </div>
                    <div className="flex flex-col">
                      <span className="font-medium text-foreground">{product.name}</span>
                      <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-sm mt-1">
                        <span className="font-serif text-primary">{formatCurrency(product.price)}</span>
                        {product.categoryId && categories && (
                          <span className="text-muted-foreground text-xs bg-muted px-2 py-0.5 rounded-full">
                            {categories.find(c => c.id === product.categoryId)?.name || 'قسم محذوف'}
                          </span>
                        )}
                        {product.bestSeller && (
                          <span className="text-xs bg-accent text-accent-foreground px-2 py-0.5 rounded-full font-medium border border-accent-foreground/10">
                            الأكثر طلبًا
                          </span>
                        )}
                        {product.costPrice && (
                          <span className="text-xs text-muted-foreground opacity-60">التكلفة: {formatCurrency(product.costPrice)}</span>
                        )}
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-2 justify-end sm:justify-start">
                    <Button variant="outline" size="sm" onClick={() => openEditForm(product)}>
                      <Pencil className="h-4 w-4 sm:me-2" />
                      <span className="hidden sm:inline">تعديل</span>
                    </Button>
                    <AlertDialog>
                      <AlertDialogTrigger asChild>
                        <Button variant="outline" size="sm" className="text-destructive hover:bg-destructive hover:text-destructive-foreground">
                          <Trash2 className="h-4 w-4 sm:me-2" />
                          <span className="hidden sm:inline">حذف</span>
                        </Button>
                      </AlertDialogTrigger>
                      <AlertDialogContent>
                        <AlertDialogHeader>
                          <AlertDialogTitle>هل أنت متأكد؟</AlertDialogTitle>
                          <AlertDialogDescription>
                            لا يمكن التراجع عن هذا الإجراء. سيتم حذف المنتج بشكل نهائي من المتجر.
                          </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                          <AlertDialogCancel>إلغاء</AlertDialogCancel>
                          <AlertDialogAction 
                            className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                            onClick={() => handleDelete(product.id)}
                          >
                            حذف
                          </AlertDialogAction>
                        </AlertDialogFooter>
                      </AlertDialogContent>
                    </AlertDialog>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center p-12 text-muted-foreground">
              {search ? 'لا توجد منتجات تطابق بحثك' : 'لا توجد منتجات في المتجر بعد'}
            </div>
          )}
        </CardContent>
      </Card>

      <Dialog open={isFormOpen} onOpenChange={setIsFormOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="font-serif text-2xl">{editingProduct ? 'تعديل منتج' : 'إضافة منتج جديد'}</DialogTitle>
          </DialogHeader>
          <ProductForm 
            product={editingProduct} 
            categories={categories || []} 
            onClose={() => setIsFormOpen(false)} 
          />
        </DialogContent>
      </Dialog>
    </div>
  );
}

function ProductForm({ product, categories, onClose }: { product: any, categories: any[], onClose: () => void }) {
  const createProduct = useCreateProduct();
  const updateProduct = useUpdateProduct();
  const queryClient = useQueryClient();
  
  const [formData, setFormData] = useState({
    name: product?.name || '',
    description: product?.description || '',
    price: product?.price?.toString() || '',
    oldPrice: product?.oldPrice?.toString() || '',
    costPrice: product?.costPrice?.toString() || '',
    categoryId: product?.categoryId?.toString() || 'none',
    bestSeller: product?.bestSeller || false,
    imageObjectPath: product?.imageObjectPath || null,
  });

  const { uploadFile, isUploading } = useUpload({
    onSuccess: (res) => {
      setFormData(prev => ({ ...prev, imageObjectPath: res.objectPath }));
      toast.success('تم رفع الصورة بنجاح');
    },
    onError: () => toast.error('فشل رفع الصورة')
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.name.trim() || !formData.price) {
      toast.error('يرجى تعبئة الحقول المطلوبة');
      return;
    }

    const payload = {
      name: formData.name.trim(),
      description: formData.description.trim() || null,
      price: parseFloat(formData.price),
      oldPrice: formData.oldPrice ? parseFloat(formData.oldPrice) : null,
      costPrice: formData.costPrice ? parseFloat(formData.costPrice) : null,
      categoryId: formData.categoryId === 'none' ? null : parseInt(formData.categoryId, 10),
      bestSeller: formData.bestSeller,
      imageObjectPath: formData.imageObjectPath,
    };

    if (product) {
      updateProduct.mutate({ id: product.id, data: payload }, {
        onSuccess: () => {
          toast.success('تم تحديث المنتج بنجاح');
          queryClient.invalidateQueries({ queryKey: getListProductsQueryKey() });
          onClose();
        },
        onError: (err: any) => {
          if (err?.status === 403) toast.error('غير مصرح لك بتعديل المنتج');
          else toast.error('حدث خطأ أثناء التحديث');
        }
      });
    } else {
      createProduct.mutate({ data: payload }, {
        onSuccess: () => {
          toast.success('تم إضافة المنتج بنجاح');
          queryClient.invalidateQueries({ queryKey: getListProductsQueryKey() });
          onClose();
        },
        onError: (err: any) => {
          if (err?.status === 403) toast.error('غير مصرح لك بإضافة منتج');
          else toast.error('حدث خطأ أثناء الإضافة');
        }
      });
    }
  };

  const isPending = createProduct.isPending || updateProduct.isPending;

  return (
    <form onSubmit={handleSubmit} className="flex flex-col gap-6 py-4">
      <div className="grid md:grid-cols-2 gap-6">
        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="name">اسم المنتج <span className="text-destructive">*</span></Label>
            <Input 
              id="name" 
              value={formData.name} 
              onChange={e => setFormData({ ...formData, name: e.target.value })} 
              required 
            />
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="price">السعر (₪) <span className="text-destructive">*</span></Label>
              <Input 
                id="price" 
                type="number" 
                step="0.01" 
                min="0"
                value={formData.price} 
                onChange={e => setFormData({ ...formData, price: e.target.value })} 
                required 
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="oldPrice">السعر القديم (للتخفيض)</Label>
              <Input 
                id="oldPrice" 
                type="number" 
                step="0.01" 
                min="0"
                value={formData.oldPrice} 
                onChange={e => setFormData({ ...formData, oldPrice: e.target.value })} 
              />
            </div>
          </div>

          <div className="space-y-2 border-t pt-4 border-dashed">
            <Label htmlFor="costPrice" className="text-muted-foreground flex items-center gap-1">
              سعر التكلفة <span className="text-xs font-normal">(مخفي عن العملاء)</span>
            </Label>
            <Input 
              id="costPrice" 
              type="number" 
              step="0.01" 
              min="0"
              value={formData.costPrice} 
              onChange={e => setFormData({ ...formData, costPrice: e.target.value })} 
              className="bg-muted/50"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="category">القسم</Label>
            <Select 
              value={formData.categoryId} 
              onValueChange={val => setFormData({ ...formData, categoryId: val })}
            >
              <SelectTrigger>
                <SelectValue placeholder="اختر القسم" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="none">بدون قسم</SelectItem>
                {categories.map(c => (
                  <SelectItem key={c.id} value={c.id.toString()}>{c.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="space-y-4">
          <div className="space-y-2">
            <Label>صورة المنتج</Label>
            {formData.imageObjectPath ? (
              <div className="relative aspect-square w-full rounded-md border bg-muted overflow-hidden">
                <img src={`/api/storage${formData.imageObjectPath}`} alt="Preview" className="w-full h-full object-cover" />
                <Button 
                  type="button"
                  variant="destructive" 
                  size="icon" 
                  className="absolute top-2 right-2 h-8 w-8 shadow-md"
                  onClick={() => setFormData({ ...formData, imageObjectPath: null })}
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>
            ) : (
              <div className="relative aspect-square w-full rounded-md border border-dashed bg-muted/30 flex flex-col items-center justify-center p-6 text-center gap-2">
                <ImageIcon className="h-8 w-8 text-muted-foreground opacity-50" />
                <p className="text-sm text-muted-foreground">لم يتم اختيار صورة</p>
                <div className="mt-2 w-full max-w-[200px] relative">
                  <Input 
                    type="file" 
                    accept="image/*"
                    className="absolute inset-0 w-full h-full opacity-0 cursor-pointer" 
                    onChange={e => e.target.files?.[0] && uploadFile(e.target.files[0])}
                    disabled={isUploading}
                  />
                  <Button type="button" variant="secondary" className="w-full pointer-events-none" disabled={isUploading}>
                    {isUploading ? <Loader2 className="h-4 w-4 animate-spin me-2" /> : <Plus className="h-4 w-4 me-2" />}
                    اختيار صورة
                  </Button>
                </div>
              </div>
            )}
          </div>

          <div className="flex items-center justify-between rounded-lg border p-4 bg-muted/20">
            <div className="space-y-0.5">
              <Label htmlFor="bestSeller" className="text-base">الأكثر طلبًا</Label>
              <p className="text-sm text-muted-foreground">سيظهر شارة "الأكثر طلبًا" على صورة المنتج</p>
            </div>
            <Switch 
              id="bestSeller" 
              checked={formData.bestSeller}
              onCheckedChange={checked => setFormData({ ...formData, bestSeller: checked })}
            />
          </div>
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="description">الوصف</Label>
        <Textarea 
          id="description" 
          rows={4}
          value={formData.description} 
          onChange={e => setFormData({ ...formData, description: e.target.value })} 
          placeholder="تفاصيل المنتج، مكوناته، وطريقة استخدامه..."
        />
      </div>

      <div className="flex justify-end gap-3 pt-4 border-t">
        <Button type="button" variant="outline" onClick={onClose}>إلغاء</Button>
        <Button type="submit" disabled={isPending}>
          {isPending ? <Loader2 className="h-4 w-4 animate-spin me-2" /> : null}
          {product ? 'حفظ التغييرات' : 'إضافة المنتج'}
        </Button>
      </div>
    </form>
  );
}