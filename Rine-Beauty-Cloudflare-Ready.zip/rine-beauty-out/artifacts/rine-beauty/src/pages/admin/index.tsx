import { useAuth } from '@workspace/replit-auth-web';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { StoreSettings } from './store-settings';
import { CategoriesManager } from './categories-manager';
import { ProductsManager } from './products-manager';
import { AdminsManager } from './admins-manager';
import { LogOut, Store, LayoutGrid, Package, ShieldAlert, Users } from 'lucide-react';
import { Link } from 'wouter';

// Kept in sync with artifacts/api-server/src/lib/adminAuth.ts — only used
// here to decide whether to show the "admins" tab; the server enforces the
// real permission check on every request.
const PRIMARY_ADMIN_EMAIL = 'eng.salah.a.barham@gmail.com';

export function AdminDashboard() {
  const { user, isLoading, isAuthenticated, login, logout } = useAuth();

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="animate-pulse flex flex-col items-center gap-4">
          <div className="h-12 w-12 rounded-full border-4 border-primary border-t-transparent animate-spin" />
          <p className="text-muted-foreground font-medium">جاري التحقق...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background px-4 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/5 to-transparent" />
        <div className="max-w-md w-full bg-card border shadow-xl rounded-xl p-8 relative z-10 flex flex-col items-center text-center">
          <div className="h-16 w-16 bg-primary/10 rounded-full flex items-center justify-center mb-6">
            <Store className="h-8 w-8 text-primary" />
          </div>
          <h1 className="font-serif text-3xl font-bold mb-2">تسجيل الدخول للإدارة</h1>
          <p className="text-muted-foreground mb-8">
            سجّل الدخول بحساب Google المصرّح له للوصول إلى لوحة تحكم المتجر.
          </p>
          <Button size="lg" className="w-full h-12 text-lg" onClick={login}>
            تسجيل الدخول عبر Google
          </Button>
          <div className="mt-8">
            <Link href="/" className="text-sm text-muted-foreground hover:text-primary transition-colors">
              &larr; العودة للمتجر
            </Link>
          </div>
        </div>
      </div>
    );
  }

  if (!user?.isAdmin) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background px-4 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-destructive/5 to-transparent" />
        <div className="max-w-md w-full bg-card border shadow-xl rounded-xl p-8 relative z-10 flex flex-col items-center text-center">
          <div className="h-16 w-16 bg-destructive/10 rounded-full flex items-center justify-center mb-6">
            <ShieldAlert className="h-8 w-8 text-destructive" />
          </div>
          <h1 className="font-serif text-3xl font-bold mb-2">غير مصرح لك بالدخول</h1>
          <p className="text-muted-foreground mb-2">
            هذا الحساب ({user?.email}) لا يملك صلاحية الوصول إلى لوحة تحكم المتجر.
          </p>
          <p className="text-muted-foreground mb-8">
            سجّل الخروج وحاول مجدداً بحساب Google المصرّح له.
          </p>
          <Button size="lg" className="w-full h-12 text-lg" onClick={logout}>
            تسجيل الخروج
          </Button>
          <div className="mt-8">
            <Link href="/" className="text-sm text-muted-foreground hover:text-primary transition-colors">
              &larr; العودة للمتجر
            </Link>
          </div>
        </div>
      </div>
    );
  }

  const isPrimaryAdmin = user?.email?.toLowerCase() === PRIMARY_ADMIN_EMAIL;

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <header className="border-b bg-card sticky top-0 z-30">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="h-8 w-8 bg-primary rounded flex items-center justify-center text-primary-foreground">
              <Store className="h-4 w-4" />
            </div>
            <h1 className="font-serif text-xl font-bold">لوحة التحكم</h1>
          </div>
          <div className="flex items-center gap-4">
            <div className="hidden sm:flex items-center gap-2 text-sm text-muted-foreground">
              {user?.profileImageUrl && (
                <img src={user.profileImageUrl} alt="" className="h-6 w-6 rounded-full" />
              )}
              <span>{user?.firstName || user?.email || 'Admin'}</span>
            </div>
            <Button variant="ghost" size="sm" onClick={logout} className="text-muted-foreground hover:text-destructive">
              <LogOut className="h-4 w-4 ms-2 rotate-180" />
              خروج
            </Button>
          </div>
        </div>
      </header>

      <main className="flex-1 container mx-auto px-4 py-8">
        <Tabs defaultValue="products" className="w-full">
          <TabsList className={`grid w-full sm:w-auto mb-8 h-12 ${isPrimaryAdmin ? 'grid-cols-4' : 'grid-cols-3'}`}>
            <TabsTrigger value="products" className="text-sm sm:text-base h-full">
              <Package className="h-4 w-4 ms-2" />
              المنتجات
            </TabsTrigger>
            <TabsTrigger value="categories" className="text-sm sm:text-base h-full">
              <LayoutGrid className="h-4 w-4 ms-2" />
              الأقسام
            </TabsTrigger>
            <TabsTrigger value="settings" className="text-sm sm:text-base h-full">
              <Store className="h-4 w-4 ms-2" />
              إعدادات المتجر
            </TabsTrigger>
            {isPrimaryAdmin && (
              <TabsTrigger value="admins" className="text-sm sm:text-base h-full">
                <Users className="h-4 w-4 ms-2" />
                المشرفون
              </TabsTrigger>
            )}
          </TabsList>

          <TabsContent value="products" className="focus-visible:outline-none">
            <ProductsManager />
          </TabsContent>

          <TabsContent value="categories" className="focus-visible:outline-none">
            <CategoriesManager />
          </TabsContent>

          <TabsContent value="settings" className="focus-visible:outline-none">
            <StoreSettings />
          </TabsContent>

          {isPrimaryAdmin && (
            <TabsContent value="admins" className="focus-visible:outline-none">
              <AdminsManager />
            </TabsContent>
          )}
        </Tabs>
      </main>
    </div>
  );
}
