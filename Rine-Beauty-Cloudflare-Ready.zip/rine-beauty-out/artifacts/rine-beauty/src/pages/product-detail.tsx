import { useParams, Link } from 'wouter';
import { useGetProduct } from '@workspace/api-client-react';
import { useCart } from '@/context/cart-context';
import { useWishlist } from '@/context/wishlist-context';
import { Button } from '@/components/ui/button';
import { ShoppingBag, Heart, ArrowRight, ChevronRight, ShieldCheck, Package, MessageCircle } from 'lucide-react';
import { cn, formatCurrency } from '@/lib/utils';
import { toast } from 'sonner';
import { useState } from 'react';
import { Skeleton } from '@/components/ui/skeleton';

export function ProductDetail() {
  const params = useParams();
  const productId = parseInt(params.id || '0', 10);
  
  const { data: product, isLoading, isError } = useGetProduct(productId, {
    query: { enabled: !!productId, queryKey: ['product', productId] }
  });

  const { addItem, increment } = useCart();
  const { toggleWishlist, isInWishlist } = useWishlist();
  const [quantity, setQuantity] = useState(1);

  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-12">
        <div className="grid md:grid-cols-2 gap-12">
          <Skeleton className="aspect-[4/5] rounded-md" />
          <div className="flex flex-col gap-6 pt-10">
            <Skeleton className="h-10 w-2/3" />
            <Skeleton className="h-8 w-1/3" />
            <Skeleton className="h-32 w-full mt-6" />
          </div>
        </div>
      </div>
    );
  }

  if (isError || !product) {
    return (
      <div className="container mx-auto px-4 py-24 text-center flex flex-col items-center gap-4">
        <h2 className="text-2xl font-serif">المنتج غير موجود</h2>
        <p className="text-muted-foreground">عذراً، لم نتمكن من العثور على المنتج الذي تبحث عنه.</p>
        <Link href="/">
          <Button className="mt-4">العودة للرئيسية</Button>
        </Link>
      </div>
    );
  }

  const isWishlisted = isInWishlist(product.id);

  const handleAddToCart = () => {
    addItem({
      id: product.id,
      name: product.name,
      price: product.price,
      image: product.imageObjectPath ? `/api/storage${product.imageObjectPath}` : null,
    });
    for (let i = 1; i < quantity; i++) {
      increment(product.id);
    }
    toast.success('تمت الإضافة للسلة', {
      description: `${quantity} × ${product.name}`,
    });
  };

  return (
    <div className="container mx-auto px-4 py-12 pb-24">
      <nav className="flex items-center text-sm text-muted-foreground mb-8">
        <Link href="/" className="hover:text-foreground transition-colors">الرئيسية</Link>
        <ChevronRight className="h-4 w-4 mx-2 rotate-180" />
        <span className="text-foreground font-medium">{product.name}</span>
      </nav>

      <div className="grid md:grid-cols-2 gap-12 lg:gap-20">
        {/* Product Image */}
        <div className="aspect-[4/5] bg-gradient-to-b from-muted to-muted/40 rounded-2xl overflow-hidden shadow-[0_20px_45px_-20px_rgba(0,0,0,0.3)] ring-1 ring-black/[0.04] relative">
          {product.imageObjectPath ? (
            <img
              src={`/api/storage${product.imageObjectPath}`}
              alt={product.name}
              className="w-full h-full object-cover object-center"
            />
          ) : (
            <div className="w-full h-full flex items-center justify-center text-muted-foreground">
              بدون صورة
            </div>
          )}
          <div className="pointer-events-none absolute inset-0 rounded-2xl bg-gradient-to-t from-black/10 via-transparent to-transparent" />
          
          {product.oldPrice && (
            <div className="absolute top-4 right-4 bg-destructive text-destructive-foreground px-3 py-1.5 text-sm font-bold rounded-sm shadow-md">
              تخفيض
            </div>
          )}

          {product.bestSeller && (
            <div className="absolute bottom-4 start-4 bg-primary text-primary-foreground px-3 py-1.5 text-sm font-bold rounded-sm shadow-md">
              الأكثر طلبًا
            </div>
          )}
        </div>

        {/* Product Info */}
        <div className="flex flex-col pt-4 md:pt-10">
          <h1 className="text-4xl lg:text-5xl font-serif font-bold text-foreground leading-tight mb-4">
            {product.name}
          </h1>
          
          <div className="flex items-end gap-4 mb-8">
            <span className="text-3xl font-serif font-bold text-primary">{formatCurrency(product.price)}</span>
            {product.oldPrice && (
              <span className="text-xl text-muted-foreground line-through decoration-destructive mb-1">
                {formatCurrency(product.oldPrice)}
              </span>
            )}
          </div>

          <div className="prose prose-sm md:prose-base dark:prose-invert text-muted-foreground mb-10 max-w-none whitespace-pre-line">
            {product.description || 'لا يوجد وصف متاح لهذا المنتج.'}
          </div>

          <div className="space-y-6 mt-auto">
            <div className="flex items-center gap-4">
              <div className="flex items-center border rounded-md h-14 bg-card w-32">
                <Button 
                  variant="ghost" 
                  className="h-full px-4 rounded-none text-lg"
                  onClick={() => setQuantity(q => Math.max(1, q - 1))}
                >
                  -
                </Button>
                <span className="flex-1 text-center font-medium text-lg">{quantity}</span>
                <Button 
                  variant="ghost" 
                  className="h-full px-4 rounded-none text-lg"
                  onClick={() => setQuantity(q => q + 1)}
                >
                  +
                </Button>
              </div>

              <Button 
                size="lg" 
                className="h-14 flex-1 text-lg shadow-md hover:-translate-y-0.5 transition-transform"
                onClick={handleAddToCart}
              >
                <ShoppingBag className="me-2 h-5 w-5" />
                أضف للسلة
              </Button>
            </div>

            <Button
              variant="outline"
              size="lg"
              className={cn(
                "w-full h-14 text-lg transition-colors border-2",
                isWishlisted && "border-primary text-primary hover:bg-primary/5"
              )}
              onClick={() => toggleWishlist(product)}
            >
              <Heart className={cn("me-2 h-5 w-5", isWishlisted && "fill-primary")} />
              {isWishlisted ? 'في المفضلة' : 'أضف للمفضلة'}
            </Button>
          </div>
          
          {/* Trust badges */}
          <div className="grid grid-cols-3 gap-4 mt-12 pt-8 border-t border-border/50 text-center">
            <div className="flex flex-col items-center gap-2 text-muted-foreground">
              <div className="h-10 w-10 rounded-full bg-secondary flex items-center justify-center text-secondary-foreground mb-1"><ShieldCheck className="h-5 w-5" /></div>
              <span className="text-xs font-medium">جودة مضمونة</span>
            </div>
            <div className="flex flex-col items-center gap-2 text-muted-foreground">
              <div className="h-10 w-10 rounded-full bg-secondary flex items-center justify-center text-secondary-foreground mb-1"><Package className="h-5 w-5" /></div>
              <span className="text-xs font-medium">تغليف آمن</span>
            </div>
            <div className="flex flex-col items-center gap-2 text-muted-foreground">
              <div className="h-10 w-10 rounded-full bg-secondary flex items-center justify-center text-secondary-foreground mb-1"><MessageCircle className="h-5 w-5" /></div>
              <span className="text-xs font-medium">دعم مباشر</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}