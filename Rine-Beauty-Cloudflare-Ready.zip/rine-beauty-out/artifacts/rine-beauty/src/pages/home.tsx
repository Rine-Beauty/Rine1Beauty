import { useState } from 'react';
import { useListProducts, useListCategories } from '@workspace/api-client-react';
import { ProductCard } from '@/components/product-card';
import { Input } from '@/components/ui/input';
import { Search } from 'lucide-react';
import { useLocation } from 'wouter';
import { cn } from '@/lib/utils';
import { useStoreSettings } from '@/hooks/use-store-settings';

export function Home() {
  const [location] = useLocation();
  const searchParams = new URLSearchParams(window.location.search);
  const categoryIdParam = searchParams.get('category');
  
  const [search, setSearch] = useState('');
  const [activeCategory, setActiveCategory] = useState<number | null>(
    categoryIdParam ? parseInt(categoryIdParam, 10) : null
  );

  const { data: categories } = useListCategories();
  const { data: products, isLoading } = useListProducts({
    search: search || undefined,
    categoryId: activeCategory || undefined,
  });
  
  const { bannerUrl, tagline, storeName } = useStoreSettings();

  return (
    <div className="flex flex-col pb-20">
      {/* Hero Banner */}
      {!activeCategory && !search && (
        <section className="relative h-[60vh] md:h-[70vh] flex items-center justify-center overflow-hidden bg-muted">
          {bannerUrl ? (
            <img src={bannerUrl} alt="Store Banner" className="absolute inset-0 w-full h-full object-cover object-center" />
          ) : (
            <div className="absolute inset-0 w-full h-full bg-gradient-to-r from-primary/20 to-primary/5" />
          )}
          <div className="absolute inset-0 bg-black/20" />
          <div className="relative z-10 text-center px-4 max-w-3xl mx-auto flex flex-col items-center gap-6 text-white drop-shadow-md">
            <h1 className="font-serif text-5xl md:text-7xl font-bold tracking-tight">{storeName}</h1>
            <p className="text-xl md:text-2xl font-light opacity-90 max-w-xl">{tagline}</p>
          </div>
        </section>
      )}

      {/* Main Content */}
      <div className="container mx-auto px-4 mt-12 flex flex-col gap-10">
        
        {/* Header & Filters */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
          <h2 className="font-serif text-3xl font-bold text-foreground">
            {activeCategory ? categories?.find(c => c.id === activeCategory)?.name : 'كل المنتجات'}
          </h2>
          
          <div className="flex flex-col sm:flex-row gap-4 w-full md:w-auto">
            <div className="relative w-full sm:w-72">
              <Search className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                type="search"
                placeholder="ابحث عن منتج..."
                className="pl-3 pr-10 bg-card"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
              />
            </div>
          </div>
        </div>

        {/* Categories Bar */}
        {categories && categories.length > 0 && (
          <div className="flex overflow-x-auto pb-4 -mx-4 px-4 sm:mx-0 sm:px-0 gap-3 scrollbar-hide">
            <button
              onClick={() => setActiveCategory(null)}
              className={cn(
                "px-5 py-2 rounded-full whitespace-nowrap text-sm font-medium transition-colors border",
                activeCategory === null
                  ? "bg-primary text-primary-foreground border-primary"
                  : "bg-card text-foreground hover:bg-muted border-border"
              )}
            >
              الكل
            </button>
            {categories.map((cat) => (
              <button
                key={cat.id}
                onClick={() => setActiveCategory(cat.id)}
                className={cn(
                  "px-5 py-2 rounded-full whitespace-nowrap text-sm font-medium transition-colors border",
                  activeCategory === cat.id
                    ? "bg-primary text-primary-foreground border-primary"
                    : "bg-card text-foreground hover:bg-muted border-border"
                )}
              >
                {cat.name}
              </button>
            ))}
          </div>
        )}

        {/* Product Grid */}
        {isLoading ? (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-x-4 gap-y-10 animate-pulse">
            {[1, 2, 3, 4, 5, 6, 7, 8].map((n) => (
              <div key={n} className="flex flex-col gap-3">
                <div className="aspect-[4/5] bg-muted rounded-md" />
                <div className="h-4 bg-muted rounded w-2/3" />
                <div className="h-5 bg-muted rounded w-1/3" />
              </div>
            ))}
          </div>
        ) : products && products.length > 0 ? (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-x-4 gap-y-10">
            {products.map((product, i) => (
              <div key={product.id} className="animate-in fade-in slide-in-from-bottom-4" style={{ animationDelay: `${i * 50}ms`, animationFillMode: 'both' }}>
                <ProductCard product={product} />
              </div>
            ))}
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center py-20 text-center gap-4">
            <div className="w-20 h-20 bg-muted rounded-full flex items-center justify-center">
              <Search className="h-8 w-8 text-muted-foreground" />
            </div>
            <h3 className="text-xl font-medium">لا توجد منتجات</h3>
            <p className="text-muted-foreground">لم نتمكن من العثور على أي منتجات تطابق بحثك.</p>
            {(search || activeCategory) && (
              <button
                onClick={() => { setSearch(''); setActiveCategory(null); }}
                className="text-primary font-medium hover:underline mt-2"
              >
                مسح عوامل التصفية
              </button>
            )}
          </div>
        )}
      </div>
    </div>
  );
}