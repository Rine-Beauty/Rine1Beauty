import { useQuery } from '@tanstack/react-query';
import { useGetSettings } from '@workspace/api-client-react';

export function useStoreSettings() {
  const { data: settings, isLoading } = useGetSettings();

  return {
    settings,
    isLoading,
    storeName: settings?.storeName || 'Rine Beauty',
    tagline: settings?.tagline || 'Curated Skincare & Haircare',
    backgroundColor: settings?.backgroundColor || '#F9F6F0',
    instagramUrl: settings?.instagramUrl,
    whatsappNumber: settings?.whatsappNumber,
    logoUrl: settings?.logoObjectPath ? `/api/storage${settings.logoObjectPath}` : undefined,
    bannerUrl: settings?.bannerObjectPath ? `/api/storage${settings.bannerObjectPath}` : undefined,
  };
}