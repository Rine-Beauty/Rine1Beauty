import { formatCurrency } from '@/lib/utils';

export type WhatsappOrderItem = {
  name: string;
  price: number;
  qty: number;
};

function buildWhatsappUrl(whatsappNumber: string, message: string): string {
  const formattedNumber = whatsappNumber.replace(/[^0-9]/g, '');
  return `https://wa.me/${formattedNumber}?text=${encodeURIComponent(message)}`;
}

export function sendInquiryToWhatsapp(whatsappNumber: string, storeName: string) {
  const message = `مرحبا ${storeName}، عندي استفسار`;
  window.open(buildWhatsappUrl(whatsappNumber, message), '_blank', 'noopener,noreferrer');
}

export function sendOrderToWhatsapp(
  whatsappNumber: string,
  storeName: string,
  items: WhatsappOrderItem[],
  total: number
) {
  const lines = items
    .map(i => `- ${i.name} × ${i.qty} = ${formatCurrency(i.price * i.qty)}`)
    .join('\n');
  const message = `مرحبا ${storeName}، أريد طلب:\n${lines}\n\nالإجمالي: ${formatCurrency(total)}`;
  window.open(buildWhatsappUrl(whatsappNumber, message), '_blank', 'noopener,noreferrer');
}
