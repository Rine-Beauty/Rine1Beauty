import { useState } from 'react';
import { Link, useLocation } from 'wouter';
import { ShoppingBag, Heart, Menu, Search, User } from 'lucide-react';
import { useCart } from '@/context/cart-context';
import { useWishlist } from '@/context/wishlist-context';
import { useStoreSettings } from '@/hooks/use-store-settings';
import { CartDrawer } from './cart-drawer';
import { WishlistDrawer } from './wishlist-drawer';
import { SocialLinks, FloatingWhatsappButton } from './social-links';
import { Button } from '@/components/ui/button';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';

export function Layout({ children }: { children: React.ReactNode }) {
  const { storeName, logoUrl } = useStoreSettings();
  const { totalCount: cartCount } = useCart();
  const { wishlistCount } = useWishlist();
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isWishlistOpen, setIsWishlistOpen] = useState(false);

  return (
    <div className="min-h-[100dvh] flex flex-col bg-background text-foreground font-sans selection:bg-primary selection:text-primary-foreground">
      <header className="sticky top-0 z-50 w-full border-b border-border/40 bg-background/80 backdrop-blur-md">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Sheet>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon" className="md:hidden">
                  <Menu className="h-5 w-5" />
                  <span className="sr-only">القائمة</span>
                </Button>
              </SheetTrigger>
              <SheetContent side="right" className="w-[300px] sm:w-[400px]">
                <nav className="flex flex-col gap-4 mt-8">
                  <Link href="/" className="text-lg font-medium hover:text-primary transition-colors">
                    الرئيسية
                  </Link>
                  <Link href="/admin" className="text-lg font-medium hover:text-primary transition-colors">
                    لوحة التحكم
                  </Link>
                </nav>
              </SheetContent>
            </Sheet>

            <Link href="/" className="flex items-center gap-2">
              {logoUrl ? (
                <span className="h-10 w-10 shrink-0 rounded-full overflow-hidden border border-border/60 bg-card">
                  <img src={logoUrl} alt={storeName} className="h-full w-full object-cover object-center" />
                </span>
              ) : (
                <span className="font-serif text-xl font-bold tracking-tight text-primary">
                  {storeName}
                </span>
              )}
            </Link>

            <nav className="hidden md:flex items-center gap-6 ms-8">
              <Link href="/" className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors">
                الرئيسية
              </Link>
            </nav>
          </div>

          <div className="flex items-center gap-2">
            <Button variant="ghost" size="icon" onClick={() => setIsWishlistOpen(true)} className="relative">
              <Heart className="h-5 w-5" />
              {wishlistCount > 0 && (
                <span className="absolute top-1 right-1 h-2 w-2 rounded-full bg-primary" />
              )}
              <span className="sr-only">المفضلة</span>
            </Button>
            
            <Button variant="ghost" size="icon" onClick={() => setIsCartOpen(true)} className="relative">
              <ShoppingBag className="h-5 w-5" />
              {cartCount > 0 && (
                <span className="absolute -top-1 -right-1 h-4 w-4 rounded-full bg-primary text-[10px] font-bold text-primary-foreground flex items-center justify-center">
                  {cartCount}
                </span>
              )}
              <span className="sr-only">السلة</span>
            </Button>

            <Link href="/admin" className="hidden sm:inline-flex">
              <Button variant="ghost" size="icon">
                <User className="h-5 w-5" />
                <span className="sr-only">حسابي</span>
              </Button>
            </Link>
          </div>
        </div>
      </header>

      <main className="flex-1">
        {children}
      </main>

      <footer className="border-t border-border bg-card mt-auto">
        <div className="container mx-auto px-4 py-8 md:py-12 flex flex-col md:flex-row justify-between items-center gap-6">
          <div className="flex items-center gap-2">
            {logoUrl ? (
              <span className="h-10 w-10 shrink-0 rounded-full overflow-hidden border border-border/60 opacity-60 grayscale hover:grayscale-0 hover:opacity-100 transition-all">
                <img src={logoUrl} alt={storeName} className="h-full w-full object-cover object-center" />
              </span>
            ) : (
              <span className="font-serif text-xl font-bold tracking-tight text-muted-foreground">
                {storeName}
              </span>
            )}
          </div>
          <SocialLinks />

          <p className="text-sm text-muted-foreground text-center md:text-start">
            جميع الحقوق محفوظة &copy; {new Date().getFullYear()} {storeName}
          </p>
        </div>
      </footer>

      <CartDrawer open={isCartOpen} onOpenChange={setIsCartOpen} />
      <WishlistDrawer open={isWishlistOpen} onOpenChange={setIsWishlistOpen} />
      <FloatingWhatsappButton />
    </div>
  );
}