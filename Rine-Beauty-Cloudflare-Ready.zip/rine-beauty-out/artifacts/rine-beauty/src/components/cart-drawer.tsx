import { Sheet, SheetContent, SheetHeader, SheetTitle } from '@/components/ui/sheet';
import { Button } from '@/components/ui/button';
import { useCart } from '@/context/cart-context';
import { useStoreSettings } from '@/hooks/use-store-settings';
import { formatCurrency } from '@/lib/utils';
import { sendOrderToWhatsapp } from '@/lib/whatsapp';
import { Minus, Plus, Trash2 } from 'lucide-react';
import { ScrollArea } from '@/components/ui/scroll-area';

export function CartDrawer({ open, onOpenChange }: { open: boolean; onOpenChange: (open: boolean) => void }) {
  const { items, increment, decrement, remove, totalPrice } = useCart();
  const { storeName, whatsappNumber } = useStoreSettings();

  const handleCheckout = () => {
    if (!whatsappNumber) {
      alert('لم يتم تكوين رقم الواتساب للمتجر بعد.');
      return;
    }

    sendOrderToWhatsapp(whatsappNumber, storeName, items, totalPrice);
  };

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent side="left" className="flex flex-col w-full sm:max-w-md">
        <SheetHeader>
          <SheetTitle className="font-serif text-2xl text-start">سلة المشتريات</SheetTitle>
        </SheetHeader>

        {items.length === 0 ? (
          <div className="flex-1 flex flex-col items-center justify-center gap-4">
            <div className="w-20 h-20 bg-muted rounded-full flex items-center justify-center">
              <span className="text-4xl text-muted-foreground">!</span>
            </div>
            <p className="text-muted-foreground font-medium">السلة فارغة</p>
            <Button variant="outline" onClick={() => onOpenChange(false)}>
              مواصلة التسوق
            </Button>
          </div>
        ) : (
          <>
            <ScrollArea className="flex-1 -mx-6 px-6">
              <div className="flex flex-col gap-6 py-6">
                {items.map((item) => (
                  <div key={item.id} className="flex gap-4 group">
                    <div className="h-24 w-20 shrink-0 overflow-hidden rounded-md border bg-muted">
                      {item.image ? (
                        <img
                          src={item.image}
                          alt={item.name}
                          className="h-full w-full object-cover object-center"
                        />
                      ) : (
                        <div className="h-full w-full flex items-center justify-center bg-secondary text-muted-foreground text-xs">
                          بدون صورة
                        </div>
                      )}
                    </div>

                    <div className="flex flex-1 flex-col">
                      <div className="flex justify-between text-base font-medium text-foreground">
                        <h3 className="line-clamp-2 leading-tight">{item.name}</h3>
                        <p className="ms-4 shrink-0 font-serif">{formatCurrency(item.price)}</p>
                      </div>
                      
                      <div className="flex flex-1 items-end justify-between text-sm">
                        <div className="flex items-center border rounded-md h-8">
                          <Button 
                            variant="ghost" 
                            size="icon" 
                            className="h-full w-8 rounded-none"
                            onClick={() => decrement(item.id)}
                          >
                            <Minus className="h-3 w-3" />
                          </Button>
                          <span className="w-8 text-center tabular-nums">{item.qty}</span>
                          <Button 
                            variant="ghost" 
                            size="icon" 
                            className="h-full w-8 rounded-none"
                            onClick={() => increment(item.id)}
                          >
                            <Plus className="h-3 w-3" />
                          </Button>
                        </div>

                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8 text-destructive opacity-50 group-hover:opacity-100 transition-opacity"
                          onClick={() => remove(item.id)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </ScrollArea>

            <div className="border-t py-6 flex flex-col gap-4">
              <div className="flex justify-between text-lg font-medium">
                <p>المجموع</p>
                <p className="font-serif">{formatCurrency(totalPrice)}</p>
              </div>
              <p className="text-sm text-muted-foreground">
                إتمام الطلب سيتم عبر الواتساب مع صاحبة المتجر شخصياً.
              </p>
              <Button size="lg" className="w-full text-lg h-14" onClick={handleCheckout}>
                الطلب عبر الواتساب
              </Button>
            </div>
          </>
        )}
      </SheetContent>
    </Sheet>
  );
}