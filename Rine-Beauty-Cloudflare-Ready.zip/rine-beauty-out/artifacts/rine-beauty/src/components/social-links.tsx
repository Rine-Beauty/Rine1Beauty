import { Instagram } from 'lucide-react';
import { useStoreSettings } from '@/hooks/use-store-settings';
import { sendInquiryToWhatsapp } from '@/lib/whatsapp';
import { cn } from '@/lib/utils';

function WhatsappIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 24 24"
      fill="currentColor"
    >
      <path d="M12.04 2C6.58 2 2.13 6.45 2.13 11.91c0 1.75.46 3.45 1.32 4.95L2 22l5.28-1.38a9.9 9.9 0 0 0 4.76 1.21h.01c5.46 0 9.9-4.45 9.9-9.91C21.96 6.45 17.51 2 12.04 2Zm0 18.14h-.01a8.2 8.2 0 0 1-4.19-1.15l-.3-.18-3.13.82.84-3.05-.2-.31a8.2 8.2 0 0 1-1.26-4.37c0-4.54 3.7-8.24 8.26-8.24 2.2 0 4.27.86 5.83 2.42a8.18 8.18 0 0 1 2.42 5.83c0 4.55-3.7 8.24-8.26 8.24Zm4.52-6.17c-.25-.12-1.47-.72-1.7-.81-.23-.08-.39-.12-.56.13-.17.25-.64.81-.78.97-.14.17-.29.19-.54.06-.25-.12-1.04-.38-1.98-1.22-.73-.65-1.22-1.45-1.37-1.69-.14-.25-.02-.38.11-.5.11-.11.25-.29.37-.43.13-.14.17-.25.25-.41.08-.17.04-.31-.02-.44-.06-.12-.56-1.34-.76-1.84-.2-.48-.4-.42-.56-.42-.14-.01-.31-.01-.48-.01a.92.92 0 0 0-.67.31c-.23.25-.87.85-.87 2.07s.89 2.4 1.02 2.57c.12.17 1.75 2.67 4.24 3.74.59.26 1.05.41 1.41.52.59.19 1.13.16 1.55.1.47-.07 1.47-.6 1.68-1.18.21-.58.21-1.08.14-1.18-.06-.11-.23-.17-.48-.29Z" />
    </svg>
  );
}

export function SocialLinks({ className }: { className?: string }) {
  const { storeName, instagramUrl, whatsappNumber } = useStoreSettings();

  if (!instagramUrl && !whatsappNumber) return null;

  return (
    <div className={cn('flex items-center gap-3', className)}>
      {whatsappNumber && (
        <button
          type="button"
          onClick={() => sendInquiryToWhatsapp(whatsappNumber, storeName)}
          aria-label="واتساب"
          className="h-10 w-10 flex items-center justify-center rounded-full bg-[#25D366] text-white shadow-sm shadow-[#25D366]/30 transition-transform hover:scale-110 hover:shadow-md hover:shadow-[#25D366]/40"
        >
          <WhatsappIcon className="h-5 w-5" />
        </button>
      )}
      {instagramUrl && (
        <a
          href={instagramUrl}
          target="_blank"
          rel="noopener noreferrer"
          aria-label="Instagram"
          className="h-10 w-10 flex items-center justify-center rounded-full text-white shadow-sm transition-transform hover:scale-110 hover:shadow-md"
          style={{ background: 'radial-gradient(circle at 30% 110%, #fdf497 0%, #fdf497 5%, #fd5949 45%, #d6249f 60%, #285AEB 90%)' }}
        >
          <Instagram className="h-5 w-5" />
        </a>
      )}
    </div>
  );
}

export function FloatingWhatsappButton() {
  const { storeName, whatsappNumber } = useStoreSettings();

  if (!whatsappNumber) return null;

  return (
    <button
      type="button"
      onClick={() => sendInquiryToWhatsapp(whatsappNumber, storeName)}
      aria-label="تواصل معنا عبر واتساب"
      className="fixed bottom-5 end-5 z-40 h-14 w-14 flex items-center justify-center rounded-full bg-[#25D366] text-white shadow-lg shadow-[#25D366]/40 transition-transform hover:scale-110 animate-in fade-in zoom-in"
    >
      <span className="absolute inset-0 rounded-full bg-[#25D366] opacity-60 animate-ping" />
      <WhatsappIcon className="h-7 w-7 relative" />
    </button>
  );
}
