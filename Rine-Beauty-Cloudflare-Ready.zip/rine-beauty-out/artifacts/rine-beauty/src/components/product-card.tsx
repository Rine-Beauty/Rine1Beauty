import { useState } from 'react';
import { Link } from 'wouter';
import { Product } from '@workspace/api-client-react';
import { Button } from '@/components/ui/button';
import { Heart, ShoppingBag, Plus, Check } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { useCart } from '@/context/cart-context';
import { useWishlist } from '@/context/wishlist-context';
import { cn, formatCurrency } from '@/lib/utils';
import { toast } from 'sonner';

export function ProductCard({ product }: { product: Product }) {
  const { addItem } = useCart();
  const { toggleWishlist, isInWishlist } = useWishlist();
  const isWishlisted = isInWishlist(product.id);
  const [justAdded, setJustAdded] = useState(false);

  const handleAddToCart = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    addItem({
      id: product.id,
      name: product.name,
      price: product.price,
      image: product.imageObjectPath ? `/api/storage${product.imageObjectPath}` : null,
    });
    toast.success('تمت الإضافة للسلة', {
      description: product.name,
      duration: 2000,
    });
  };

  const handleQuickAdd = (e: React.MouseEvent) => {
    handleAddToCart(e);
    setJustAdded(true);
    setTimeout(() => setJustAdded(false), 900);
  };

  const handleToggleWishlist = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    toggleWishlist(product);
  };

  return (
    <div className="group relative flex flex-col gap-3">
      <Link href={`/product/${product.id}`} className="block relative aspect-[4/5] overflow-hidden rounded-2xl bg-gradient-to-b from-muted to-muted/40 shadow-[0_12px_28px_-14px_rgba(0,0,0,0.25)] ring-1 ring-black/[0.04]">
        {product.imageObjectPath ? (
          <img
            src={`/api/storage${product.imageObjectPath}`}
            alt={product.name}
            className="h-full w-full object-cover object-center transition-transform duration-500 group-hover:scale-105"
          />
        ) : (
          <div className="h-full w-full flex items-center justify-center text-muted-foreground text-sm">
            بدون صورة
          </div>
        )}
        <div className="pointer-events-none absolute inset-0 rounded-2xl bg-gradient-to-t from-black/10 via-transparent to-transparent" />
        
        {product.oldPrice && (
          <div className="absolute top-2 right-2 bg-destructive text-destructive-foreground px-2 py-1 text-xs font-bold rounded-sm">
            تخفيض
          </div>
        )}

        {product.bestSeller && (
          <div className="absolute bottom-2 start-2 bg-primary text-primary-foreground px-2 py-1 text-xs font-bold rounded-sm shadow-md">
            الأكثر طلبًا
          </div>
        )}

        <div className="absolute top-2 left-2 flex flex-col gap-2 opacity-0 -translate-x-2 group-hover:opacity-100 group-hover:translate-x-0 transition-all duration-300">
          <Button
            variant="secondary"
            size="icon"
            className="h-9 w-9 rounded-full shadow-sm hover:bg-primary hover:text-primary-foreground"
            onClick={handleToggleWishlist}
          >
            <Heart className={cn("h-4 w-4", isWishlisted && "fill-primary text-primary hover:fill-primary-foreground hover:text-primary-foreground")} />
          </Button>
        </div>
        
        <div className="hidden md:block absolute bottom-0 inset-x-0 p-3 translate-y-full opacity-0 group-hover:translate-y-0 group-hover:opacity-100 transition-all duration-300">
          <Button 
            className="w-full shadow-md font-medium" 
            onClick={handleAddToCart}
          >
            <ShoppingBag className="w-4 h-4 me-2" />
            أضف للسلة
          </Button>
        </div>

        {/* Mobile-only quick-add button: hover overlays above don't work well with touch, so give mobile a persistent tap target instead. */}
        <motion.button
          type="button"
          onClick={handleQuickAdd}
          aria-label="أضف للسلة"
          whileTap={{ scale: 0.85 }}
          className={cn(
            "flex md:hidden absolute bottom-2 end-2 h-9 w-9 items-center justify-center rounded-full shadow-md transition-colors",
            justAdded ? "bg-primary text-primary-foreground" : "bg-background/90 text-primary border border-primary/30"
          )}
        >
          <AnimatePresence mode="wait" initial={false}>
            {justAdded ? (
              <motion.span
                key="check"
                initial={{ scale: 0.4, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.4, opacity: 0 }}
                transition={{ duration: 0.2 }}
              >
                <Check className="h-4 w-4" />
              </motion.span>
            ) : (
              <motion.span
                key="plus"
                initial={{ scale: 0.4, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.4, opacity: 0 }}
                transition={{ duration: 0.2 }}
              >
                <Plus className="h-4 w-4" />
              </motion.span>
            )}
          </AnimatePresence>
        </motion.button>
      </Link>
      
      <div className="flex flex-col gap-1 px-1">
        <Link href={`/product/${product.id}`} className="font-medium text-foreground hover:text-primary transition-colors line-clamp-1">
          {product.name}
        </Link>
        <div className="flex items-baseline gap-2 font-serif text-lg">
          <span className="text-primary font-bold">{formatCurrency(product.price)}</span>
          {product.oldPrice && (
            <span className="text-sm text-muted-foreground line-through decoration-destructive">{formatCurrency(product.oldPrice)}</span>
          )}
        </div>
      </div>
    </div>
  );
}