import { Sheet, SheetContent, SheetHeader, SheetTitle } from '@/components/ui/sheet';
import { Button } from '@/components/ui/button';
import { useWishlist } from '@/context/wishlist-context';
import { useCart } from '@/context/cart-context';
import { Trash2, ShoppingBag } from 'lucide-react';
import { formatCurrency } from '@/lib/utils';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Link } from 'wouter';

export function WishlistDrawer({ open, onOpenChange }: { open: boolean; onOpenChange: (open: boolean) => void }) {
  const { items, toggleWishlist } = useWishlist();
  const { addItem } = useCart();

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent side="left" className="flex flex-col w-full sm:max-w-md">
        <SheetHeader>
          <SheetTitle className="font-serif text-2xl text-start">المفضلة</SheetTitle>
        </SheetHeader>

        {items.length === 0 ? (
          <div className="flex-1 flex flex-col items-center justify-center gap-4">
            <div className="w-20 h-20 bg-muted rounded-full flex items-center justify-center">
              <HeartIcon className="h-8 w-8 text-muted-foreground" />
            </div>
            <p className="text-muted-foreground font-medium">قائمة المفضلة فارغة</p>
            <Button variant="outline" onClick={() => onOpenChange(false)}>
              تصفح المنتجات
            </Button>
          </div>
        ) : (
          <ScrollArea className="flex-1 -mx-6 px-6">
            <div className="flex flex-col gap-6 py-6">
              {items.map((product) => (
                <div key={product.id} className="flex gap-4 group">
                  <Link href={`/product/${product.id}`} onClick={() => onOpenChange(false)} className="shrink-0">
                    <div className="h-24 w-20 overflow-hidden rounded-md border bg-muted">
                      {product.imageObjectPath ? (
                        <img
                          src={`/api/storage${product.imageObjectPath}`}
                          alt={product.name}
                          className="h-full w-full object-cover object-center"
                        />
                      ) : (
                        <div className="h-full w-full flex items-center justify-center bg-secondary text-muted-foreground text-xs">
                          بدون صورة
                        </div>
                      )}
                    </div>
                  </Link>

                  <div className="flex flex-1 flex-col">
                    <div className="flex justify-between text-base font-medium text-foreground">
                      <Link href={`/product/${product.id}`} onClick={() => onOpenChange(false)} className="line-clamp-2 leading-tight hover:text-primary transition-colors">
                        {product.name}
                      </Link>
                      <p className="ms-4 shrink-0 font-serif">{formatCurrency(product.price)}</p>
                    </div>
                    
                    <div className="flex flex-1 items-end justify-between text-sm pt-2">
                      <Button 
                        size="sm"
                        variant="secondary"
                        className="h-8 text-xs"
                        onClick={() =>
                          addItem({
                            id: product.id,
                            name: product.name,
                            price: product.price,
                            image: product.imageObjectPath ? `/api/storage${product.imageObjectPath}` : null,
                          })
                        }
                      >
                        <ShoppingBag className="h-3 w-3 me-2" />
                        أضف للسلة
                      </Button>

                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8 text-destructive opacity-50 group-hover:opacity-100 transition-opacity"
                        onClick={() => toggleWishlist(product)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </ScrollArea>
        )}
      </SheetContent>
    </Sheet>
  );
}

function HeartIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z" />
    </svg>
  );
}