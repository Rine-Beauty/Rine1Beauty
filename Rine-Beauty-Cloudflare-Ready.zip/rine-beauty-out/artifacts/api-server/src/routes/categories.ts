import { Router, type IRouter } from "express";
import { eq } from "drizzle-orm";
import { db, categoriesTable, productsTable } from "@workspace/db";
import {
  CreateCategoryBody,
  ListCategoriesResponse,
  CreateCategoryResponse,
  DeleteCategoryParams,
} from "@workspace/api-zod";
import { isStoreAdmin } from "../lib/adminAuth";

const router: IRouter = Router();

router.get("/categories", async (_req, res): Promise<void> => {
  const categories = await db
    .select()
    .from(categoriesTable)
    .orderBy(categoriesTable.name);
  res.json(ListCategoriesResponse.parse(categories));
});

router.post("/categories", async (req, res): Promise<void> => {
  if (!req.isAuthenticated()) {
    res.status(401).json({ error: "Not authenticated" });
    return;
  }
  if (!(await isStoreAdmin(req.user.email))) {
    res.status(403).json({ error: "Not authorized" });
    return;
  }

  const parsed = CreateCategoryBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [category] = await db
    .insert(categoriesTable)
    .values(parsed.data)
    .returning();

  res.status(201).json(CreateCategoryResponse.parse(category));
});

router.delete("/categories/:id", async (req, res): Promise<void> => {
  if (!req.isAuthenticated()) {
    res.status(401).json({ error: "Not authenticated" });
    return;
  }
  if (!(await isStoreAdmin(req.user.email))) {
    res.status(403).json({ error: "Not authorized" });
    return;
  }

  const params = DeleteCategoryParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  // Detach products from this category before deleting it.
  await db
    .update(productsTable)
    .set({ categoryId: null })
    .where(eq(productsTable.categoryId, params.data.id));

  const [category] = await db
    .delete(categoriesTable)
    .where(eq(categoriesTable.id, params.data.id))
    .returning();

  if (!category) {
    res.status(404).json({ error: "Category not found" });
    return;
  }

  res.sendStatus(204);
});

export default router;
