import { Router, type IRouter } from "express";
import { and, desc, eq, ilike } from "drizzle-orm";
import { db, productsTable } from "@workspace/db";
import {
  ListProductsQueryParams,
  ListProductsResponse,
  CreateProductBody,
  CreateProductResponse,
  GetProductParams,
  GetProductResponse,
  UpdateProductParams,
  UpdateProductBody,
  UpdateProductResponse,
  DeleteProductParams,
} from "@workspace/api-zod";
import { isStoreAdmin } from "../lib/adminAuth";

const router: IRouter = Router();

router.get("/products", async (req, res): Promise<void> => {
  const query = ListProductsQueryParams.safeParse(req.query);
  if (!query.success) {
    res.status(400).json({ error: query.error.message });
    return;
  }

  const { categoryId, search, bestSeller } = query.data;
  const conditions = [];
  if (categoryId !== undefined) {
    conditions.push(eq(productsTable.categoryId, categoryId));
  }
  if (bestSeller !== undefined) {
    conditions.push(eq(productsTable.bestSeller, bestSeller));
  }
  if (search) {
    conditions.push(ilike(productsTable.name, `%${search}%`));
  }

  const products = await db
    .select()
    .from(productsTable)
    .where(conditions.length > 0 ? and(...conditions) : undefined)
    .orderBy(desc(productsTable.createdAt));

  res.json(ListProductsResponse.parse(products));
});

router.post("/products", async (req, res): Promise<void> => {
  if (!req.isAuthenticated()) {
    res.status(401).json({ error: "Not authenticated" });
    return;
  }
  if (!(await isStoreAdmin(req.user.email))) {
    res.status(403).json({ error: "Not authorized" });
    return;
  }

  const parsed = CreateProductBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [product] = await db
    .insert(productsTable)
    .values({
      name: parsed.data.name,
      description: parsed.data.description ?? null,
      price: parsed.data.price,
      oldPrice: parsed.data.oldPrice ?? null,
      costPrice: parsed.data.costPrice ?? null,
      bestSeller: parsed.data.bestSeller ?? false,
      categoryId: parsed.data.categoryId ?? null,
      imageObjectPath: parsed.data.imageObjectPath ?? null,
    })
    .returning();

  res.status(201).json(CreateProductResponse.parse(product));
});

router.get("/products/:id", async (req, res): Promise<void> => {
  const params = GetProductParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [product] = await db
    .select()
    .from(productsTable)
    .where(eq(productsTable.id, params.data.id));

  if (!product) {
    res.status(404).json({ error: "Product not found" });
    return;
  }

  res.json(GetProductResponse.parse(product));
});

router.patch("/products/:id", async (req, res): Promise<void> => {
  if (!req.isAuthenticated()) {
    res.status(401).json({ error: "Not authenticated" });
    return;
  }
  if (!(await isStoreAdmin(req.user.email))) {
    res.status(403).json({ error: "Not authorized" });
    return;
  }

  const params = UpdateProductParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const parsed = UpdateProductBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const update: Record<string, unknown> = {};
  if (parsed.data.name !== undefined) update.name = parsed.data.name;
  if (parsed.data.description !== undefined)
    update.description = parsed.data.description;
  if (parsed.data.price !== undefined) update.price = parsed.data.price;
  if (parsed.data.oldPrice !== undefined)
    update.oldPrice = parsed.data.oldPrice ?? null;
  if (parsed.data.costPrice !== undefined)
    update.costPrice = parsed.data.costPrice ?? null;
  if (parsed.data.bestSeller !== undefined)
    update.bestSeller = parsed.data.bestSeller;
  if (parsed.data.categoryId !== undefined)
    update.categoryId = parsed.data.categoryId;
  if (parsed.data.imageObjectPath !== undefined)
    update.imageObjectPath = parsed.data.imageObjectPath;

  const [product] = await db
    .update(productsTable)
    .set(update)
    .where(eq(productsTable.id, params.data.id))
    .returning();

  if (!product) {
    res.status(404).json({ error: "Product not found" });
    return;
  }

  res.json(UpdateProductResponse.parse(product));
});

router.delete("/products/:id", async (req, res): Promise<void> => {
  if (!req.isAuthenticated()) {
    res.status(401).json({ error: "Not authenticated" });
    return;
  }
  if (!(await isStoreAdmin(req.user.email))) {
    res.status(403).json({ error: "Not authorized" });
    return;
  }

  const params = DeleteProductParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [product] = await db
    .delete(productsTable)
    .where(eq(productsTable.id, params.data.id))
    .returning();

  if (!product) {
    res.status(404).json({ error: "Product not found" });
    return;
  }

  res.sendStatus(204);
});

export default router;
