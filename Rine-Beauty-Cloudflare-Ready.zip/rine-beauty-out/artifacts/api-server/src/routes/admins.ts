import { Router, type IRouter, type Request, type Response } from 'express';

import {
  addAdmin,
  CannotRemovePrimaryAdminError,
  isPrimaryAdmin,
  listAdmins,
  removeAdmin,
} from '../lib/adminAuth';

const router: IRouter = Router();

function requirePrimaryAdmin(req: Request, res: Response): boolean {
  if (!req.isAuthenticated() || !isPrimaryAdmin(req.user?.email)) {
    res.status(403).json({ error: 'Only the primary admin can manage admins' });
    return false;
  }
  return true;
}

router.get('/admins', async (req: Request, res: Response) => {
  if (!requirePrimaryAdmin(req, res)) return;
  const admins = await listAdmins();
  res.json({ admins });
});

router.post('/admins', async (req: Request, res: Response) => {
  if (!requirePrimaryAdmin(req, res)) return;

  const { email } = req.body ?? {};
  if (typeof email !== 'string' || !email.includes('@')) {
    res.status(400).json({ error: 'A valid email is required' });
    return;
  }

  await addAdmin(email, req.user!.email!);
  res.json({ admins: await listAdmins() });
});

router.delete('/admins/:email', async (req: Request, res: Response) => {
  if (!requirePrimaryAdmin(req, res)) return;

  try {
    await removeAdmin(req.params.email);
  } catch (err) {
    if (err instanceof CannotRemovePrimaryAdminError) {
      res.status(400).json({ error: err.message });
      return;
    }
    throw err;
  }

  res.json({ admins: await listAdmins() });
});

export default router;
