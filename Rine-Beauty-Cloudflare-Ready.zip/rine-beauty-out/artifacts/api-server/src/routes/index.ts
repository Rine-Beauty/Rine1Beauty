import { Router, type IRouter } from "express";
import healthRouter from "./health";
import authRouter from "./auth";
import storageRouter from "./storage";
import categoriesRouter from "./categories";
import productsRouter from "./products";
import settingsRouter from "./settings";
import adminsRouter from "./admins";

const router: IRouter = Router();

router.use(healthRouter);
router.use(authRouter);
router.use(storageRouter);
router.use(categoriesRouter);
router.use(productsRouter);
router.use(settingsRouter);
router.use(adminsRouter);

export default router;
