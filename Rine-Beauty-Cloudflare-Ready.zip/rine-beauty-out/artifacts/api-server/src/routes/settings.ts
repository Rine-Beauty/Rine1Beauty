import { Router, type IRouter } from "express";
import { eq } from "drizzle-orm";
import { db, storeSettingsTable } from "@workspace/db";
import {
  GetSettingsResponse,
  UpdateSettingsBody,
  UpdateSettingsResponse,
} from "@workspace/api-zod";
import { isStoreAdmin } from "../lib/adminAuth";

const router: IRouter = Router();

async function getOrCreateSettings() {
  const [existing] = await db.select().from(storeSettingsTable).limit(1);
  if (existing) return existing;

  const [created] = await db
    .insert(storeSettingsTable)
    .values({
      storeName: "Rine Beauty",
      tagline: "منتجات العناية بالبشرة والشعر",
      whatsappNumber: "972568148040",
      instagramUrl: "https://www.instagram.com/rine.beauty_/",
    })
    .returning();

  return created;
}

router.get("/settings", async (_req, res): Promise<void> => {
  const settings = await getOrCreateSettings();
  res.json(GetSettingsResponse.parse(settings));
});

router.put("/settings", async (req, res): Promise<void> => {
  if (!req.isAuthenticated()) {
    res.status(401).json({ error: "Not authenticated" });
    return;
  }
  if (!(await isStoreAdmin(req.user.email))) {
    res.status(403).json({ error: "Not authorized" });
    return;
  }

  const parsed = UpdateSettingsBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const current = await getOrCreateSettings();

  const [updated] = await db
    .update(storeSettingsTable)
    .set(parsed.data)
    .where(
      // Singleton row -- always update the one we just fetched/created.
      eq(storeSettingsTable.id, current.id),
    )
    .returning();

  res.json(UpdateSettingsResponse.parse(updated));
});

export default router;
