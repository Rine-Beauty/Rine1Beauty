import { db, adminsTable } from '@workspace/db';
import { eq } from 'drizzle-orm';

// The primary admin is always an admin, can never be removed, and is the
// only one allowed to add/remove other admins. Everyone else is stored in
// the `admins` table and managed from the dashboard.
export const PRIMARY_ADMIN_EMAIL = 'eng.salah.a.barham@gmail.com';

function normalize(email: string): string {
  return email.trim().toLowerCase();
}

export function isPrimaryAdmin(email: string | null | undefined): boolean {
  if (!email) return false;
  return normalize(email) === PRIMARY_ADMIN_EMAIL;
}

export async function isStoreAdmin(
  email: string | null | undefined,
): Promise<boolean> {
  if (!email) return false;
  const normalized = normalize(email);
  if (normalized === PRIMARY_ADMIN_EMAIL) return true;

  const [row] = await db
    .select()
    .from(adminsTable)
    .where(eq(adminsTable.email, normalized));
  return !!row;
}

export async function listAdmins(): Promise<
  Array<{ email: string; addedBy: string | null; createdAt: Date; isPrimary: boolean }>
> {
  const rows = await db.select().from(adminsTable);
  return [
    {
      email: PRIMARY_ADMIN_EMAIL,
      addedBy: null,
      createdAt: new Date(0),
      isPrimary: true,
    },
    ...rows
      .map((r) => ({ ...r, isPrimary: false }))
      .sort((a, b) => a.email.localeCompare(b.email)),
  ];
}

export async function addAdmin(
  email: string,
  addedBy: string,
): Promise<void> {
  const normalized = normalize(email);
  if (normalized === PRIMARY_ADMIN_EMAIL) return; // already admin
  await db
    .insert(adminsTable)
    .values({ email: normalized, addedBy: normalize(addedBy) })
    .onConflictDoNothing();
}

export class CannotRemovePrimaryAdminError extends Error {
  constructor() {
    super('The primary admin cannot be removed');
    this.name = 'CannotRemovePrimaryAdminError';
  }
}

export async function removeAdmin(email: string): Promise<void> {
  const normalized = normalize(email);
  if (normalized === PRIMARY_ADMIN_EMAIL) {
    throw new CannotRemovePrimaryAdminError();
  }
  await db.delete(adminsTable).where(eq(adminsTable.email, normalized));
}
