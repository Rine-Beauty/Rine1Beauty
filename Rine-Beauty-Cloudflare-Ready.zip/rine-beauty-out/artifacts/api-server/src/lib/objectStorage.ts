import { randomUUID } from 'crypto';
import { Readable } from 'stream';
import {
  S3Client,
  GetObjectCommand,
  PutObjectCommand,
  HeadObjectCommand,
  CopyObjectCommand,
} from '@aws-sdk/client-s3';
import { getSignedUrl } from '@aws-sdk/s3-request-presigner';

import {
  canAccessObject,
  getObjectAclPolicy,
  ObjectAclPolicy,
  ObjectPermission,
  setObjectAclPolicy,
} from './objectAcl';

// --- Cloudflare R2 client -------------------------------------------------
// R2 is S3-compatible, so the AWS SDK works against it by pointing the
// endpoint at the account's R2 URL. Needs these env vars:
//   R2_ACCOUNT_ID, R2_ACCESS_KEY_ID, R2_SECRET_ACCESS_KEY, R2_BUCKET_NAME

function requireEnv(name: string): string {
  const value = process.env[name];
  if (!value) {
    throw new Error(`${name} is not set. See .env.example for R2 setup.`);
  }
  return value;
}

let _s3: S3Client | null = null;
function getS3Client(): S3Client {
  if (!_s3) {
    const accountId = requireEnv('R2_ACCOUNT_ID');
    _s3 = new S3Client({
      region: 'auto',
      endpoint: `https://${accountId}.r2.cloudflarestorage.com`,
      credentials: {
        accessKeyId: requireEnv('R2_ACCESS_KEY_ID'),
        secretAccessKey: requireEnv('R2_SECRET_ACCESS_KEY'),
      },
    });
  }
  return _s3;
}

function getBucketName(): string {
  return requireEnv('R2_BUCKET_NAME');
}

export class ObjectNotFoundError extends Error {
  constructor() {
    super('Object not found');
    this.name = 'ObjectNotFoundError';
    Object.setPrototypeOf(this, ObjectNotFoundError.prototype);
  }
}

// Minimal wrapper mimicking the subset of the @google-cloud/storage File
// API that objectAcl.ts relies on, so that file stays unchanged.
export class ObjectFile {
  constructor(public readonly key: string) {}

  get name(): string {
    return this.key;
  }

  async exists(): Promise<[boolean]> {
    try {
      await getS3Client().send(
        new HeadObjectCommand({ Bucket: getBucketName(), Key: this.key }),
      );
      return [true];
    } catch {
      return [false];
    }
  }

  async getMetadata(): Promise<
    [{ contentType?: string; size?: number; metadata?: Record<string, string> }]
  > {
    const res = await getS3Client().send(
      new HeadObjectCommand({ Bucket: getBucketName(), Key: this.key }),
    );
    return [
      {
        contentType: res.ContentType,
        size: res.ContentLength,
        metadata: res.Metadata,
      },
    ];
  }

  async setMetadata(opts: { metadata: Record<string, string> }): Promise<void> {
    const [current] = await this.getMetadata();
    // S3/R2 has no in-place metadata update — copy the object onto itself
    // with the new metadata (REPLACE directive).
    await getS3Client().send(
      new CopyObjectCommand({
        Bucket: getBucketName(),
        Key: this.key,
        CopySource: `${getBucketName()}/${this.key}`,
        ContentType: current.contentType,
        Metadata: { ...current.metadata, ...opts.metadata },
        MetadataDirective: 'REPLACE',
      }),
    );
  }

  async createReadStream(): Promise<Readable> {
    const res = await getS3Client().send(
      new GetObjectCommand({ Bucket: getBucketName(), Key: this.key }),
    );
    return res.Body as Readable;
  }
}

export class ObjectStorageService {
  constructor() {}

  getPublicObjectSearchPaths(): Array<string> {
    const pathsStr = process.env.PUBLIC_OBJECT_SEARCH_PATHS || 'public';
    const paths = Array.from(
      new Set(
        pathsStr
          .split(',')
          .map((p) => p.trim().replace(/^\/+|\/+$/g, ''))
          .filter((p) => p.length > 0),
      ),
    );
    return paths;
  }

  getPrivateObjectDir(): string {
    return (process.env.PRIVATE_OBJECT_DIR || 'private').replace(
      /^\/+|\/+$/g,
      '',
    );
  }

  async searchPublicObject(filePath: string): Promise<ObjectFile | null> {
    for (const searchPath of this.getPublicObjectSearchPaths()) {
      const key = `${searchPath}/${filePath}`;
      const file = new ObjectFile(key);
      const [exists] = await file.exists();
      if (exists) return file;
    }
    return null;
  }

  async downloadObject(
    file: ObjectFile,
    cacheTtlSec: number = 3600,
  ): Promise<Response> {
    const [metadata] = await file.getMetadata();
    const aclPolicy = await getObjectAclPolicy(file);
    const isPublic = aclPolicy?.visibility === 'public';

    const nodeStream = await file.createReadStream();
    const webStream = Readable.toWeb(nodeStream) as ReadableStream;

    const headers: Record<string, string> = {
      'Content-Type': metadata.contentType || 'application/octet-stream',
      'Cache-Control': `${isPublic ? 'public' : 'private'}, max-age=${cacheTtlSec}`,
    };
    if (metadata.size) {
      headers['Content-Length'] = String(metadata.size);
    }

    return new Response(webStream, { headers });
  }

  async getObjectEntityUploadURL(): Promise<string> {
    const privateObjectDir = this.getPrivateObjectDir();
    const objectId = randomUUID();
    const key = `${privateObjectDir}/uploads/${objectId}`;

    return getSignedUrl(
      getS3Client(),
      new PutObjectCommand({ Bucket: getBucketName(), Key: key }),
      { expiresIn: 900 },
    );
  }

  async getObjectEntityFile(objectPath: string): Promise<ObjectFile> {
    if (!objectPath.startsWith('/objects/')) {
      throw new ObjectNotFoundError();
    }

    const entityId = objectPath.slice('/objects/'.length);
    const key = `${this.getPrivateObjectDir()}/${entityId}`;
    const file = new ObjectFile(key);
    const [exists] = await file.exists();
    if (!exists) {
      throw new ObjectNotFoundError();
    }
    return file;
  }

  // Presigned upload URLs point straight at R2; extract the /objects/<id>
  // path our own API uses to reference it afterward.
  normalizeObjectEntityPath(rawPath: string): string {
    let pathname: string;
    try {
      pathname = new URL(rawPath).pathname;
    } catch {
      return rawPath;
    }

    let objectEntityDir = this.getPrivateObjectDir();
    if (!objectEntityDir.endsWith('/')) objectEntityDir = `${objectEntityDir}/`;
    // R2 presigned URL paths look like /<bucket>/<key> or just /<key>
    // depending on client — strip the bucket prefix if present.
    const bucket = getBucketName();
    let key = pathname.replace(/^\//, '');
    if (key.startsWith(`${bucket}/`)) key = key.slice(bucket.length + 1);

    if (!key.startsWith(objectEntityDir)) {
      return pathname;
    }
    const entityId = key.slice(objectEntityDir.length);
    return `/objects/${entityId}`;
  }

  async trySetObjectEntityAclPolicy(
    rawPath: string,
    aclPolicy: ObjectAclPolicy,
  ): Promise<string> {
    const normalizedPath = this.normalizeObjectEntityPath(rawPath);
    if (!normalizedPath.startsWith('/')) {
      return normalizedPath;
    }
    const objectFile = await this.getObjectEntityFile(normalizedPath);
    await setObjectAclPolicy(objectFile, aclPolicy);
    return normalizedPath;
  }

  async canAccessObjectEntity({
    userId,
    objectFile,
    requestedPermission,
  }: {
    userId?: string;
    objectFile: ObjectFile;
    requestedPermission?: ObjectPermission;
  }): Promise<boolean> {
    return canAccessObject({
      userId,
      objectFile,
      requestedPermission: requestedPermission ?? ObjectPermission.READ,
    });
  }
}
