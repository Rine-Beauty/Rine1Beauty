---
name: Orval zod v3/v4 mismatch
description: format email/uri fields in OpenAPI specs break orval's zod codegen under a zod v3 workspace pin
---

Orval v8's zod client emits top-level v4-style calls (`zod.email()`, `zod.url()`) for any OpenAPI string field with `format: email` or `format: uri`. If the workspace's `zod` package is pinned to v3.x (check `pnpm-workspace.yaml` catalog), these calls don't exist and the generated `lib/api-zod/src/generated/api.ts` fails `tsc --build` with TS2339.

**Why:** this is not obvious from the OpenAPI spec or orval config — it only surfaces after running codegen and the chained `typecheck:libs` step, and the failure is in generated code, not authored code.

**How to apply:** before adding `format: email` / `format: uri` to any schema field in `lib/api-spec/openapi.yaml`, check the installed zod major version. If it's v3, omit those formats (plain `type: string` is fine — OpenAPI format is metadata, not enforced validation) and re-run `pnpm --filter @workspace/api-spec run codegen` to confirm a clean typecheck before building on top of it. This also affects the Replit Auth skill's reference OpenAPI schemas (`AuthUser.email`, mobile token exchange `redirect_uri`), which use these formats by default.
