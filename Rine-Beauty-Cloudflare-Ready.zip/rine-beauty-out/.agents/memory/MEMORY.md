# Memory Index

- [Orval zod v3/v4 mismatch](orval-zod-v3-v4-mismatch.md) — `format: email`/`format: uri` in OpenAPI triggers zod-v4-only codegen output that breaks under pinned zod v3.
- [Web lib package tsconfig](web-lib-package-composite-tsconfig.md) — new `lib/*-web` packages need `composite: true` + `declarationMap: true` or referencing packages fail `tsc --build`.
