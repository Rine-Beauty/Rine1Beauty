---
name: Web lib package composite tsconfig
description: new lib/*-web packages (e.g. copied from replit-auth or object-storage skill templates) need composite project settings wired correctly
---

When copying a skill's web-client template into `lib/<name>-web/` (e.g. `replit-auth-web`, `object-storage-web`) and referencing it from an artifact's `tsconfig.json` via TypeScript project references:

1. The new package's own `tsconfig.json` must have `"composite": true` and `"declarationMap": true` in `compilerOptions`, or any project that references it fails `tsc --build` with `TS6306: Referenced project '...' must have setting "composite": true`.
2. If the package uses `import.meta.env.*` (e.g. to read `BASE_URL`) but doesn't depend on `vite` as a package, don't add `"types": ["vite/client"]` to its tsconfig — that fails with `TS2688: Cannot find type definition file for 'vite/client'` since the type package isn't installed in that workspace. Instead add a minimal local ambient `.d.ts` (e.g. `src/vite-env.d.ts`) declaring just `ImportMetaEnv`/`ImportMeta` with the fields actually used.
3. Add the new package to the root `tsconfig.json` references array and to any consuming artifact's `tsconfig.json` references array, and run `pnpm -w run typecheck:libs` before typechecking the consuming artifact.

**Why:** these templates are written generically and don't always match the exact composite/project-reference wiring a given monorepo instance needs; the errors only surface at `tsc --build` time, one layer removed from the file you just copied.

**How to apply:** whenever copying an `-web` lib template from a skill (replit-auth, object-storage, etc.), proactively check/fix these three things before assuming codegen or the frontend build will succeed.
